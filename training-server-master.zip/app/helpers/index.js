export const parseModal = ({ modal, parser}) => {

}

import main from '../modules/main';
import authen from '../modules/authen';
import account from '../modules/account';
import twitter from '../modules/twitter';

export default {
  main,
  authen,
  account,
  twitter,
}

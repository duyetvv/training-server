import OAuth from 'oauth';

const OAuth2 = OAuth.OAuth2;
const twitterApi = 'https://api.twitter.com/';
const consumerKey = '4igJTTTM4Jcds5XFDcGmGKr6t';
const consumerSecret = 'eDt2fSeZMTZZHOG6J2BXBNRKeNOwEpPjSA72lz92dywfGQPWBV';

const oauth2 = new OAuth2(
  consumerKey,
  consumerSecret,
  '',
  twitterApi,
  'oauth2/token',
  null
);

export const authTwitter = (req, res) => {
  oauth2.getOAuthAccessToken(
    '',
    { grant_type: 'client_credentials' },
    (error, access_token, refresh_token, results) => {
      console.log(error, access_token, refresh_token, results);

      if (error) {
        res.json({ status: 0 });
      } else {
        res.json({ status: 1 });
      }
    }
  )
}


export const authTwitterCb = (req, res) => {
  console.log(req, res);
  res.json({ demo: '' });
}

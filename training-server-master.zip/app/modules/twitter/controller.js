const Twitter = require('twitter');
const OAuth2 = require('oauth').OAuth2;

const clientID = 'nEjdZThujT7nVO9IvpFgE6qgK';
const clientSecret = 'r1bTCpVIc26te5VpLG1243FoflJTVgmuSL3Rg6bqqJ93hPzbic';
const baseSite = 'https://api.twitter.com/';
const authorizePath = null;
const accessTokenPath = 'oauth2/token';
const customHeaders = null;

const oauth2 = new OAuth2(
  clientID,
  clientSecret,
  baseSite,
  authorizePath,
  accessTokenPath,
  customHeaders
)

export const authTwitter = (req, res) => {
  oauth2.getOAuthAccessToken(
    '',
    { 'grant_type': 'client_credentials' },
    (errors, access_token, refresh_token, results) => {
      if (errors) {
        res.json({ status: false, errors: { type: 'authentication fail' } });
      } else {
        res.json({ status: true, data: results });
      }
    });
}

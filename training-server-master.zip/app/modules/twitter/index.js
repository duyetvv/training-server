
import { authTwitter, authTwitterCb } from './controller';

const twitter = (router) => {
  router.route('/auth/twitter').post(authTwitter);
  router.route('/auth/twither/callback').post(authTwitterCb);
}

export default twitter;

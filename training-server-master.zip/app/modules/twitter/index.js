
import { authTwitter } from './controller';

const twitter = (router) => {
  router.route('/auth/twitter').post(authTwitter);
}

export default twitter;

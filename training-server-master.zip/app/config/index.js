export const connectString = 'mongodb://localhost:27017/';
export const dbName = 'ShoppingApp';
